package com.my.misecretocontigo.alejandrostudios.mx;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import io.getstream.photoview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String version = "";
	private String link = "";
	private double PERMISO_CODIGO = 0;
	private String permiso = "";
	private double requestCode = 0;
	private String permissions = "";
	private double grantResults = 0;
	
	private ArrayList<HashMap<String, Object>> Map = new ArrayList<>();
	private ArrayList<String> string = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map_vercion = new ArrayList<>();
	private ArrayList<String> string_vercion = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview1;
	private ProgressBar progressbar1;
	private TextView textview1;
	
	private Intent intent = new Intent();
	private TimerTask timer;
	private RequestNetwork very;
	private RequestNetwork.RequestListener _very_request_listener;
	private AlertDialog.Builder dialog;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private SharedPreferences Usuario1;
	private DatabaseReference datauser = _firebase.getReference("Usuario ");
	private ChildEventListener _datauser_child_listener;
	private SharedPreferences vinculo;
	private SharedPreferences ajustes;
	private DatabaseReference vercion = _firebase.getReference("vercion");
	private ChildEventListener _vercion_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		imageview1 = findViewById(R.id.imageview1);
		progressbar1 = findViewById(R.id.progressbar1);
		textview1 = findViewById(R.id.textview1);
		very = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		auth = FirebaseAuth.getInstance();
		Usuario1 = getSharedPreferences("Usuario", Activity.MODE_PRIVATE);
		vinculo = getSharedPreferences("vinculo", Activity.MODE_PRIVATE);
		ajustes = getSharedPreferences("ajustes", Activity.MODE_PRIVATE);
		
		_very_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (string_vercion.contains("vercion")) {
						if (version.equals(map_vercion.get((int)string_vercion.indexOf("vercion")).get("vercion_apk").toString())) {
							if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()) {
								if (!string.contains(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
									if (!string.contains("studioswolffid")) {
										timer = new TimerTask() {
											@Override
											public void run() {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
													}
												});
											}
										};
										_timer.schedule(timer, (int)(5000));
									} else {
										dialog.setTitle("Vamos a crear tu perfil ");
										dialog.setIcon(R.drawable.ic_account_box_black);
										dialog.setMessage("Estamos a un paso para terminar ");
										dialog.setPositiveButton("Crear perfil ", new DialogInterface.OnClickListener() {
											@Override
											public void onClick(DialogInterface _dialog, int _which) {
												intent.putExtra("contraseña", getIntent().getStringExtra("contraseña"));
												intent.setClass(getApplicationContext(), PerfilActivity.class);
												intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
												startActivity(intent);
												finish();
											}
										});
										dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
											@Override
											public void onClick(DialogInterface _dialog, int _which) {
												finish();
											}
										});
										dialog.setCancelable(false);
										dialog.create().show();
									}
								} else {
									if (!string.contains("studioswolffid")) {
										timer = new TimerTask() {
											@Override
											public void run() {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
													}
												});
											}
										};
										_timer.schedule(timer, (int)(2000));
									} else {
										Usuario1.edit().putString("Nombre", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Nombre").toString()).commit();
										Usuario1.edit().putString("Perfíl ", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Perfil").toString()).commit();
										Usuario1.edit().putString("Apellidos", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Apellidos").toString()).commit();
										Usuario1.edit().putString("Fecha de nacimiento", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Fecha de nacimiento").toString()).commit();
										Usuario1.edit().putString("Genero", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Genero").toString()).commit();
										Usuario1.edit().putString("Creado", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Creado").toString()).commit();
										vinculo.edit().putString("vinculo", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Referido").toString()).commit();
										vinculo.edit().putString("Fecha", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Referido-fecha").toString()).commit();
										vinculo.edit().putString("Nombre", Map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Referido-nombre").toString()).commit();
										if (ajustes.getString("seguridad", "").equals("true")) {
											intent.setClass(getApplicationContext(), AccesoActivity.class);
											intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
											startActivity(intent);
											finish();
										} else {
											if (Usuario1.getString("Genero", "").equals("Masculino")) {
												SketchwareUtil.showMessage(getApplicationContext(), "Bienvenido ".concat(Usuario1.getString("Nombre", "").concat("!")));
											} else {
												SketchwareUtil.showMessage(getApplicationContext(), "Bienvenida ".concat(Usuario1.getString("Nombre", "").concat("!")));
											}
											intent.setClass(getApplicationContext(), HomeActivity.class);
											intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
											startActivity(intent);
											finish();
										}
									}
								}
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "Por favor verifica tu correo electrónico ");
								intent.setClass(getApplicationContext(), LoginActivity.class);
								intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(intent);
								finish();
							}
						} else {
							link = map_vercion.get((int)string_vercion.indexOf("vercion")).get("link").toString();
							version = map_vercion.get((int)string_vercion.indexOf("vercion")).get("vercion_apk").toString();
							dialog.setTitle("Actualización Disponible");
							dialog.setIcon(R.drawable.icon_system_update_round);
							dialog.setMessage("La nueva versión v".concat(version.concat(", ya está lista. Incluye mejoras importantes y correcciones.\n¡Actualiza ahora para una mejor experiencia!\n")));
							dialog.setPositiveButton("Actualizar", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									intent.setData(Uri.parse(link));
									intent.setAction(Intent.ACTION_VIEW);
									startActivity(intent);
									finish();
								}
							});
							dialog.setCancelable(false);
							dialog.create().show();
						}
					} else {
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
									}
								});
							}
						};
						_timer.schedule(timer, (int)(2000));
					}
				} else {
					intent.setClass(getApplicationContext(), LoginActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(intent);
					finish();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				dialog.setTitle("Ups!");
				dialog.setIcon(R.drawable.ic_signal_wifi_statusbar_not_connected_black);
				dialog.setMessage("Por favor verifica tu conexión a internet o datos y intenta mas tarde ");
				dialog.setPositiveButton("Volver a intentar ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
									}
								});
							}
						};
						_timer.schedule(timer, (int)(5000));
					}
				});
				dialog.setNeutralButton("Soporte", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setClass(getApplicationContext(), SoporteActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		};
		
		_datauser_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				datauser.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						Map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								Map.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		datauser.addChildEventListener(_datauser_child_listener);
		
		_vercion_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				vercion.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map_vercion = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map_vercion.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string_vercion.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				vercion.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map_vercion = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map_vercion.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string_vercion.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		vercion.addChildEventListener(_vercion_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		version = "1.3.1 Oficial";
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
					}
				});
			}
		};
		_timer.schedule(timer, (int)(10000));
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // API 33+
			    if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_DENIED) {
				        requestPermissions(new String[] { Manifest.permission.READ_MEDIA_IMAGES }, 1000);
				    } else {
				        // Permiso ya concedido, haz lo que necesites
				    }
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { // API 23 a 32
			    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				        requestPermissions(new String[] { Manifest.permission.READ_EXTERNAL_STORAGE }, 1000);
				    } else {
				        // Permiso ya concedido, haz lo que necesites
				    }
		} else {
			    // Android versión menor a 6.0, permiso concedido por defecto
			    // Haz lo que necesites
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}