package com.my.misecretocontigo.alejandrostudios.mx;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import io.getstream.photoview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;;

public class AccesoActivity extends AppCompatActivity {
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView statusText;
	private ImageView imageview1;
	private MaterialButton materialbutton1;
	private TextView textview1;
	
	private Intent intent = new Intent();
	private RequestNetwork desbloqueo;
	private RequestNetwork.RequestListener _desbloqueo_request_listener;
	private SharedPreferences Usuario1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.acceso);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		statusText = findViewById(R.id.statusText);
		imageview1 = findViewById(R.id.imageview1);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview1 = findViewById(R.id.textview1);
		desbloqueo = new RequestNetwork(this);
		Usuario1 = getSharedPreferences("Usuario", Activity.MODE_PRIVATE);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Executor executor = ContextCompat.getMainExecutor(AccesoActivity.this);
				
				BiometricPrompt biometricPrompt = new BiometricPrompt(AccesoActivity.this, executor,
				new BiometricPrompt.AuthenticationCallback() {
						@Override
						public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
								super.onAuthenticationSucceeded(result);
								statusText.setText("¡Desbloqueado correctamente!");
								Toast.makeText(AccesoActivity.this, "Autenticación exitosa", Toast.LENGTH_SHORT).show();
						if (Usuario1.getString("Genero", "").equals("Masculino")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Bienvenido ".concat(Usuario1.getString("Nombre", "").concat("!")));
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "Bienvenida ".concat(Usuario1.getString("Nombre", "").concat("!")));
						}
						intent.setClass(getApplicationContext(), HomeActivity.class);
								startActivity(intent);
								finish();
								
						}
						
						@Override
						public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
								super.onAuthenticationError(errorCode, errString);
								statusText.setText("Error: " + errString);
								Toast.makeText(AccesoActivity.this, "Error: " + errString, Toast.LENGTH_SHORT).show();
						}
						
						@Override
						public void onAuthenticationFailed() {
								super.onAuthenticationFailed();
								statusText.setText("Autenticación fallida");
								Toast.makeText(AccesoActivity.this, "Falló la autenticación", Toast.LENGTH_SHORT).show();
						}
				});
				
				BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
				.setTitle("Verificación biométrica")
				.setSubtitle("Usa tu huella, patrón o PIN")
				.setDeviceCredentialAllowed(true)
				.build();
				
				biometricPrompt.authenticate(promptInfo);
				
			}
		});
		
		_desbloqueo_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Executor executor = ContextCompat.getMainExecutor(AccesoActivity.this);
				
				BiometricPrompt biometricPrompt = new BiometricPrompt(AccesoActivity.this, executor,
				new BiometricPrompt.AuthenticationCallback() {
						@Override
						public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
								super.onAuthenticationSucceeded(result);
								statusText.setText("¡Desbloqueado correctamente!");
								Toast.makeText(AccesoActivity.this, "Autenticación exitosa", Toast.LENGTH_SHORT).show();
						if (Usuario1.getString("Genero", "").equals("Masculino")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Bienvenido ".concat(Usuario1.getString("Nombre", "").concat("!")));
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "Bienvenida ".concat(Usuario1.getString("Nombre", "").concat("!")));
						}
						intent.setClass(getApplicationContext(), HomeActivity.class);
								startActivity(intent);
								finish();
								
						}
						
						@Override
						public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
								super.onAuthenticationError(errorCode, errString);
								statusText.setText("Error: " + errString);
								Toast.makeText(AccesoActivity.this, "Error: " + errString, Toast.LENGTH_SHORT).show();
						}
						
						@Override
						public void onAuthenticationFailed() {
								super.onAuthenticationFailed();
								statusText.setText("Autenticación fallida");
								Toast.makeText(AccesoActivity.this, "Falló la autenticación", Toast.LENGTH_SHORT).show();
						}
				});
				
				BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
				.setTitle("Verificación biométrica")
				.setSubtitle("Usa tu huella, patrón o PIN")
				.setDeviceCredentialAllowed(true)
				.build();
				
				biometricPrompt.authenticate(promptInfo);
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				Executor executor = ContextCompat.getMainExecutor(AccesoActivity.this);
				
				BiometricPrompt biometricPrompt = new BiometricPrompt(AccesoActivity.this, executor,
				new BiometricPrompt.AuthenticationCallback() {
						@Override
						public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
								super.onAuthenticationSucceeded(result);
								statusText.setText("¡Desbloqueado correctamente!");
								Toast.makeText(AccesoActivity.this, "Autenticación exitosa", Toast.LENGTH_SHORT).show();
						if (Usuario1.getString("Genero", "").equals("Masculino")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Bienvenido ".concat(Usuario1.getString("Nombre", "").concat("!")));
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "Bienvenida ".concat(Usuario1.getString("Nombre", "").concat("!")));
						}
						intent.setClass(getApplicationContext(), HomeActivity.class);
								startActivity(intent);
								finish();
								
						}
						
						@Override
						public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
								super.onAuthenticationError(errorCode, errString);
								statusText.setText("Error: " + errString);
								Toast.makeText(AccesoActivity.this, "Error: " + errString, Toast.LENGTH_SHORT).show();
						}
						
						@Override
						public void onAuthenticationFailed() {
								super.onAuthenticationFailed();
								statusText.setText("Autenticación fallida");
								Toast.makeText(AccesoActivity.this, "Falló la autenticación", Toast.LENGTH_SHORT).show();
						}
				});
				
				BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
				.setTitle("Verificación biométrica")
				.setSubtitle("Usa tu huella, patrón o PIN")
				.setDeviceCredentialAllowed(true)
				.build();
				
				biometricPrompt.authenticate(promptInfo);
				
			}
		};
	}
	
	private void initializeLogic() {
		getWindow().setFlags(
		    WindowManager.LayoutParams.FLAG_SECURE,
		    WindowManager.LayoutParams.FLAG_SECURE
		);
		statusText.setVisibility(View.GONE);
		desbloqueo.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _desbloqueo_request_listener);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}