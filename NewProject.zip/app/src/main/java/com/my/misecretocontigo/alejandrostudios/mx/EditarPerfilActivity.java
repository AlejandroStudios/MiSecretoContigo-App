package com.my.misecretocontigo.alejandrostudios.mx;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import io.getstream.photoview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class EditarPerfilActivity extends AppCompatActivity {
	
	public final int REQ_CD_FILEE = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String Nombre = "";
	private String Apellidos = "";
	private boolean imagen = false;
	private String path = "";
	private String name = "";
	private String path_img = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> map_user = new ArrayList<>();
	private ArrayList<String> string_user = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear9;
	private LinearLayout linear1;
	private ProgressBar progressbar1;
	private CircleImageView circleimageview1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear10;
	private MaterialButton materialbutton1;
	private TextView textview2;
	private EditText edittext_name;
	private TextView textview1;
	private EditText edittext_apellido;
	private TextView textview3;
	private TextView textview_fecha;
	private TextView textview4;
	private TextView textview_genero;
	private TextView textview5;
	private TextView textview_correo;
	private TextView textview7;
	private TextView textview_id;
	private TextView textview10;
	private TextView textview_vinculo;
	
	private Intent intent = new Intent();
	private AlertDialog.Builder dialog;
	private Calendar calendar = Calendar.getInstance();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private StorageReference perfil = _firebase_storage.getReference("perfil");
	private OnCompleteListener<Uri> _perfil_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _perfil_download_success_listener;
	private OnSuccessListener _perfil_delete_success_listener;
	private OnProgressListener _perfil_upload_progress_listener;
	private OnProgressListener _perfil_download_progress_listener;
	private OnFailureListener _perfil_failure_listener;
	private RequestNetwork cargador;
	private RequestNetwork.RequestListener _cargador_request_listener;
	private Intent Filee = new Intent(Intent.ACTION_GET_CONTENT);
	private SharedPreferences ajustes;
	private DatabaseReference usuario = _firebase.getReference("Usuario ");
	private ChildEventListener _usuario_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.editar_perfil);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		linear9 = findViewById(R.id.linear9);
		linear1 = findViewById(R.id.linear1);
		progressbar1 = findViewById(R.id.progressbar1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear10 = findViewById(R.id.linear10);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview2 = findViewById(R.id.textview2);
		edittext_name = findViewById(R.id.edittext_name);
		textview1 = findViewById(R.id.textview1);
		edittext_apellido = findViewById(R.id.edittext_apellido);
		textview3 = findViewById(R.id.textview3);
		textview_fecha = findViewById(R.id.textview_fecha);
		textview4 = findViewById(R.id.textview4);
		textview_genero = findViewById(R.id.textview_genero);
		textview5 = findViewById(R.id.textview5);
		textview_correo = findViewById(R.id.textview_correo);
		textview7 = findViewById(R.id.textview7);
		textview_id = findViewById(R.id.textview_id);
		textview10 = findViewById(R.id.textview10);
		textview_vinculo = findViewById(R.id.textview_vinculo);
		dialog = new AlertDialog.Builder(this);
		auth = FirebaseAuth.getInstance();
		cargador = new RequestNetwork(this);
		Filee.setType("image/*");
		Filee.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		ajustes = getSharedPreferences("ajustes", Activity.MODE_PRIVATE);
		
		circleimageview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				if (!textview_id.getText().toString().equals("Cargando...")) {
					intent.putExtra("link", path_img);
					intent.putExtra("ID", textview_id.getText().toString());
					intent.setClass(getApplicationContext(), Visualizador22Activity.class);
					startActivity(intent);
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Por favor, espera un momento...");
				}
				return true;
			}
		});
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!textview_id.getText().toString().equals("Cargando...")) {
					startActivityForResult(Filee, REQ_CD_FILEE);
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Por favor, espera un momento...");
				}
			}
		});
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_name.getText().toString().equals("")) {
					((EditText)edittext_name).setError("Por favor ingresa tu nombre");
				} else {
					if (edittext_apellido.getText().toString().equals("")) {
						((EditText)edittext_apellido).setError("Por favor ingresa tu apellido");
					} else {
						if (imagen) {
							perfil.child(name).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_perfil_failure_listener).addOnProgressListener(_perfil_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
								@Override
								public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
									return perfil.child(name).getDownloadUrl();
								}}).addOnCompleteListener(_perfil_upload_success_listener);
						} else {
							if (edittext_name.getText().toString().equals(Nombre)) {
								if (edittext_apellido.getText().toString().equals(Apellidos)) {
									SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
									intent.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intent);
									finish();
								} else {
									map = new HashMap<>();
									map.put("Apellidos", edittext_apellido.getText().toString());
									usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
									map.clear();
									SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
									intent.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intent);
									finish();
								}
							} else {
								if (edittext_apellido.getText().toString().equals(Apellidos)) {
									map = new HashMap<>();
									map.put("Nombre", edittext_name.getText().toString());
									usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
									map.clear();
									SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
									intent.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intent);
									finish();
								} else {
									map = new HashMap<>();
									map.put("Nombre", edittext_name.getText().toString());
									map.put("Apellidos", edittext_apellido.getText().toString());
									usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
									map.clear();
									SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
									intent.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intent);
									finish();
								}
							}
						}
					}
				}
			}
		});
		
		_perfil_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				progressbar1.setProgress((int)_progressValue);
				progressbar1.setVisibility(View.VISIBLE);
			}
		};
		
		_perfil_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_perfil_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				progressbar1.setVisibility(View.GONE);
				if (edittext_name.getText().toString().equals(Nombre)) {
					if (edittext_apellido.getText().toString().equals(Apellidos)) {
						map = new HashMap<>();
						map.put("Perfil", _downloadUrl);
						usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
						map.clear();
						SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
						intent.setClass(getApplicationContext(), HomeActivity.class);
						startActivity(intent);
						finish();
					} else {
						map = new HashMap<>();
						map.put("Perfil", _downloadUrl);
						map.put("Apellidos", edittext_apellido.getText().toString());
						usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
						map.clear();
						SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
						intent.setClass(getApplicationContext(), HomeActivity.class);
						startActivity(intent);
						finish();
					}
				} else {
					if (edittext_apellido.getText().toString().equals(Apellidos)) {
						map = new HashMap<>();
						map.put("Perfil", _downloadUrl);
						map.put("Nombre", edittext_name.getText().toString());
						usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
						map.clear();
						SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
						intent.setClass(getApplicationContext(), HomeActivity.class);
						startActivity(intent);
						finish();
					} else {
						map = new HashMap<>();
						map.put("Perfil", _downloadUrl);
						map.put("Nombre", edittext_name.getText().toString());
						map.put("Apellidos", edittext_apellido.getText().toString());
						usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
						map.clear();
						SketchwareUtil.showMessage(getApplicationContext(), "Perfíl Actualizado");
						intent.setClass(getApplicationContext(), HomeActivity.class);
						startActivity(intent);
						finish();
					}
				}
			}
		};
		
		_perfil_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_perfil_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_perfil_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_cargador_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (string_user.contains(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					Nombre = map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Nombre").toString();
					Apellidos = map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Apellidos").toString();
					path_img = map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Perfil").toString();
					Glide.with(getApplicationContext()).load(Uri.parse(path_img)).into(circleimageview1);
					edittext_name.setText(Nombre);
					edittext_apellido.setText(Apellidos);
					textview_correo.setText(map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Correo").toString());
					textview_id.setText(map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("ID").toString());
					textview_fecha.setText(map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Fecha de nacimiento").toString());
					textview_genero.setText(map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Genero").toString());
					if (map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Referido-nombre").toString().equals("")) {
						linear10.setVisibility(View.GONE);
					} else {
						linear10.setVisibility(View.VISIBLE);
						textview_vinculo.setText(map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Referido-nombre").toString());
					}
					materialbutton1.setVisibility(View.VISIBLE);
				} else {
					cargador.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _cargador_request_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "Cargando...");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				dialog.setTitle("Ups!");
				dialog.setIcon(R.drawable.ic_signal_wifi_statusbar_not_connected_black);
				dialog.setMessage("Por favor verifica tu conexión a internet o datos y intenta mas tarde ");
				dialog.setPositiveButton("Volver a intentar ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						cargador.startRequestNetwork(RequestNetworkController.GET, "https://google com", "A", _cargador_request_listener);
					}
				});
				dialog.setNeutralButton("Soporte", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setClass(getApplicationContext(), SoporteActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dialog.setCancelable(true);
				dialog.create().show();
			}
		};
		
		_usuario_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usuario.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map_user = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map_user.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string_user.add(_childKey);
						cargador.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _cargador_request_listener);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		usuario.addChildEventListener(_usuario_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Editar Perfil");
		cargador.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _cargador_request_listener);
		materialbutton1.setVisibility(View.GONE);
		progressbar1.setVisibility(View.GONE);
		linear10.setVisibility(View.GONE);
		name = FirebaseAuth.getInstance().getCurrentUser().getUid().concat("+".concat(""));
		edittext_apellido.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_fecha.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_correo.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_id.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_vinculo.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		edittext_name.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_genero.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		if (ajustes.getString("captura", "").equals("true")) {
			getWindow().setFlags(
			    WindowManager.LayoutParams.FLAG_SECURE,
			    WindowManager.LayoutParams.FLAG_SECURE
			);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FILEE:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				imagen = true;
				circleimageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
				path = _filePath.get((int)(0));
			}
			else {
				imagen = false;
				Glide.with(getApplicationContext()).load(Uri.parse(path_img)).into(circleimageview1);
				path = "";
			}
			break;
			default:
			break;
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}