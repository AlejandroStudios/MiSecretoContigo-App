package com.my.misecretocontigo.alejandrostudios.mx;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import io.getstream.photoview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class DataexpeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private FloatingActionButton _fab;
	private String img1 = "";
	private String img2 = "";
	private String img3 = "";
	private String img4 = "";
	private String img5 = "";
	private String img6 = "";
	private String key = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String ID = "";
	private String vinculo = "";
	
	private ArrayList<HashMap<String, Object>> mapp = new ArrayList<>();
	private ArrayList<String> map_string = new ArrayList<>();
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linear6;
	private LinearLayout linear2;
	private LinearLayout linear3_t;
	private LinearLayout linear12;
	private LinearLayout linear_d;
	private LinearLayout linear5;
	private LinearLayout linear8_g;
	private LinearLayout linear11;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear14;
	private LinearLayout linear13;
	private TextView textview7;
	private TextView textview6;
	private TextView textview5;
	private TextView textview4;
	private ImageView imageview1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView imageview4;
	private ImageView imageview5;
	private ImageView imageview6;
	private TextView textview8;
	
	private Intent intent = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private DatabaseReference experiencia = _firebase.getReference("experiencia");
	private ChildEventListener _experiencia_child_listener;
	private RequestNetwork delete;
	private RequestNetwork.RequestListener _delete_request_listener;
	private AlertDialog.Builder dialog;
	private SharedPreferences ajustes;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dataexpe);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		linear1 = findViewById(R.id.linear1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear6 = findViewById(R.id.linear6);
		linear2 = findViewById(R.id.linear2);
		linear3_t = findViewById(R.id.linear3_t);
		linear12 = findViewById(R.id.linear12);
		linear_d = findViewById(R.id.linear_d);
		linear5 = findViewById(R.id.linear5);
		linear8_g = findViewById(R.id.linear8_g);
		linear11 = findViewById(R.id.linear11);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear14 = findViewById(R.id.linear14);
		linear13 = findViewById(R.id.linear13);
		textview7 = findViewById(R.id.textview7);
		textview6 = findViewById(R.id.textview6);
		textview5 = findViewById(R.id.textview5);
		textview4 = findViewById(R.id.textview4);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		imageview5 = findViewById(R.id.imageview5);
		imageview6 = findViewById(R.id.imageview6);
		textview8 = findViewById(R.id.textview8);
		auth = FirebaseAuth.getInstance();
		delete = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		ajustes = getSharedPreferences("ajustes", Activity.MODE_PRIVATE);
		
		linear13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("Vinculo", vinculo);
				intent.putExtra("key", key);
				intent.putExtra("Titulo", getIntent().getStringExtra("Titulo"));
				intent.setClass(getApplicationContext(), ComentarioActivity.class);
				startActivity(intent);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("link", img1);
				intent.putExtra("ID", ID);
				intent.setClass(getApplicationContext(), Visualizador22Activity.class);
				startActivity(intent);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("link", img2);
				intent.putExtra("ID", ID);
				intent.setClass(getApplicationContext(), Visualizador22Activity.class);
				startActivity(intent);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("link", img3);
				intent.putExtra("ID", ID);
				intent.setClass(getApplicationContext(), Visualizador22Activity.class);
				startActivity(intent);
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("link", img4);
				intent.putExtra("ID", ID);
				intent.setClass(getApplicationContext(), Visualizador22Activity.class);
				startActivity(intent);
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("link", img5);
				intent.putExtra("ID", ID);
				intent.setClass(getApplicationContext(), Visualizador22Activity.class);
				startActivity(intent);
			}
		});
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.putExtra("link", img6);
				intent.putExtra("ID", ID);
				intent.setClass(getApplicationContext(), Visualizador22Activity.class);
				startActivity(intent);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				delete.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _delete_request_listener);
			}
		});
		
		_experiencia_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		experiencia.addChildEventListener(_experiencia_child_listener);
		
		_delete_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				dialog.setTitle("¿Borrar el secreto guardado?");
				dialog.setIcon(R.drawable.ic_delete_black);
				dialog.setMessage("Este secreto va hacer borrado permanente y no sera posible recuperarlo");
				dialog.setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						map = new HashMap<>();
						map.put("ID", ID.concat("-none"));
						map.put("Quienlove", vinculo.concat("-none"));
						experiencia.child(key).updateChildren(map);
						map.clear();
						SketchwareUtil.showMessage(getApplicationContext(), "Secreto Borrado");
						intent.setClass(getApplicationContext(), HomeActivity.class);
						startActivity(intent);
						finish();
					}
				});
				dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Por favor, verifica tu conexión a internet o datos móviles y intenta mas tarde");
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		key = getIntent().getStringExtra("key");
		img1 = getIntent().getStringExtra("img1");
		img2 = getIntent().getStringExtra("img2");
		img3 = getIntent().getStringExtra("img3");
		img4 = getIntent().getStringExtra("img4");
		img5 = getIntent().getStringExtra("img5");
		img6 = getIntent().getStringExtra("img6");
		vinculo = getIntent().getStringExtra("Vínculo");
		if (img1.equals("none")) {
			imageview1.setVisibility(View.GONE);
		}
		if (img2.equals("none")) {
			imageview2.setVisibility(View.GONE);
		}
		if (img3.equals("none")) {
			imageview3.setVisibility(View.GONE);
		}
		if (img4.equals("none")) {
			imageview4.setVisibility(View.GONE);
		}
		if (img5.equals("none")) {
			imageview5.setVisibility(View.GONE);
		}
		if (img6.equals("none")) {
			imageview6.setVisibility(View.GONE);
		}
		textview7.setText(getIntent().getStringExtra("Titulo"));
		textview6.setText(getIntent().getStringExtra("Descripcion"));
		textview5.setText(getIntent().getStringExtra("Fecha"));
		Glide.with(getApplicationContext()).load(Uri.parse(img1)).into(imageview1);
		Glide.with(getApplicationContext()).load(Uri.parse(img2)).into(imageview2);
		Glide.with(getApplicationContext()).load(Uri.parse(img3)).into(imageview3);
		Glide.with(getApplicationContext()).load(Uri.parse(img4)).into(imageview4);
		Glide.with(getApplicationContext()).load(Uri.parse(img5)).into(imageview5);
		Glide.with(getApplicationContext()).load(Uri.parse(img6)).into(imageview6);
		linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF000000));
		linear9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF000000));
		linear3_t.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		linear_d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		linear8_g.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		ID = getIntent().getStringExtra("ID");
		if (img1.equals("none") && (img2.equals("none") && (img3.equals("none") && (img4.equals("none") && (img5.equals("none") && img6.equals("none")))))) {
			linear8_g.setVisibility(View.GONE);
			linear11.setVisibility(View.GONE);
			linear5.setVisibility(View.GONE);
		} else {
			linear11.setVisibility(View.VISIBLE);
			linear5.setVisibility(View.VISIBLE);
			linear8_g.setVisibility(View.VISIBLE);
		}
		if (ajustes.getString("captura", "").equals("true")) {
			getWindow().setFlags(
			    WindowManager.LayoutParams.FLAG_SECURE,
			    WindowManager.LayoutParams.FLAG_SECURE
			);
		}
		if (!ID.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
			getWindow().setFlags(
			    WindowManager.LayoutParams.FLAG_SECURE,
			    WindowManager.LayoutParams.FLAG_SECURE
			);
			_fab.hide();
		} else {
			//Temas de seguridad
		}
		if (vinculo.equals("none")) {
			linear13.setVisibility(View.GONE);
		} else {
			linear13.setVisibility(View.VISIBLE);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}