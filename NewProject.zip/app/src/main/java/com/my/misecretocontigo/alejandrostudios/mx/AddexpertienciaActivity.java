package com.my.misecretocontigo.alejandrostudios.mx;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.core.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import io.getstream.photoview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class AddexpertienciaActivity extends AppCompatActivity {
	
	public final int REQ_CD_FILE = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private double img = 0;
	private boolean privado = false;
	private String path = "";
	private String key = "";
	private String link1 = "";
	private String link2 = "";
	private String link3 = "";
	private String link4 = "";
	private String link5 = "";
	private String link6 = "";
	private HashMap<String, Object> map = new HashMap<>();
	private boolean carga = false;
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linear6;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private MaterialButton materialbutton1;
	private TextView textview1;
	private EditText edittext_titulo;
	private TextView textview2;
	private EditText edittext_descri;
	private TextView textview3;
	private LinearLayout linear11;
	private TextView textview6;
	private RadioButton radiobutton1;
	private RadioButton radiobutton2;
	private TextView textview4;
	private ImageView imageview1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView imageview4;
	private ImageView imageview5;
	private ImageView imageview6;
	
	private Intent intet = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private DatabaseReference experiencia = _firebase.getReference("experiencia");
	private ChildEventListener _experiencia_child_listener;
	private StorageReference file_experiencia = _firebase_storage.getReference("file_experiencia");
	private OnCompleteListener<Uri> _file_experiencia_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _file_experiencia_download_success_listener;
	private OnSuccessListener _file_experiencia_delete_success_listener;
	private OnProgressListener _file_experiencia_upload_progress_listener;
	private OnProgressListener _file_experiencia_download_progress_listener;
	private OnFailureListener _file_experiencia_failure_listener;
	private AlertDialog.Builder Dialog;
	private Calendar calendar = Calendar.getInstance();
	private Intent file = new Intent(Intent.ACTION_GET_CONTENT);
	private SharedPreferences vinculo;
	private SharedPreferences ajustes;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.addexpertiencia);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear6 = findViewById(R.id.linear6);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview1 = findViewById(R.id.textview1);
		edittext_titulo = findViewById(R.id.edittext_titulo);
		textview2 = findViewById(R.id.textview2);
		edittext_descri = findViewById(R.id.edittext_descri);
		textview3 = findViewById(R.id.textview3);
		linear11 = findViewById(R.id.linear11);
		textview6 = findViewById(R.id.textview6);
		radiobutton1 = findViewById(R.id.radiobutton1);
		radiobutton2 = findViewById(R.id.radiobutton2);
		textview4 = findViewById(R.id.textview4);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		imageview5 = findViewById(R.id.imageview5);
		imageview6 = findViewById(R.id.imageview6);
		auth = FirebaseAuth.getInstance();
		Dialog = new AlertDialog.Builder(this);
		file.setType("image/*");
		file.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		vinculo = getSharedPreferences("vinculo", Activity.MODE_PRIVATE);
		ajustes = getSharedPreferences("ajustes", Activity.MODE_PRIVATE);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_titulo.getText().toString().equals("")) {
					((EditText)edittext_titulo).setError("Por favor ingrese el título");
				} else {
					if (edittext_descri.getText().toString().equals("")) {
						((EditText)edittext_descri).setError("Por favor ingrese la descripción");
					} else {
						if (carga) {
							SketchwareUtil.showMessage(getApplicationContext(), "Espera un momento por favor, mientras se encriptan y se cargan los archivos.");
						} else {
							if (privado) {
								if (img == 0) {
									map = new HashMap<>();
									map.put("Titulo", edittext_titulo.getText().toString());
									map.put("Descripcion", edittext_descri.getText().toString());
									map.put("Fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
									map.put("Quienlove", "none");
									map.put("ID", FirebaseAuth.getInstance().getCurrentUser().getUid());
									map.put("Perfil", ajustes.getString("Perfil", ""));
									map.put("Key", key);
									map.put("imagen1", "none");
									map.put("imagen2", "none");
									map.put("imagen3", "none");
									map.put("imagen4", "none");
									map.put("imagen5", "none");
									map.put("imagen6", "none");
									experiencia.child(key).updateChildren(map);
									map.clear();
									intet.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intet);
									finish();
								} else {
									map = new HashMap<>();
									map.put("Titulo", edittext_titulo.getText().toString());
									map.put("Descripcion", edittext_descri.getText().toString());
									map.put("Fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
									map.put("Quienlove", "none");
									map.put("ID", FirebaseAuth.getInstance().getCurrentUser().getUid());
									map.put("Key", key);
									map.put("Perfil", ajustes.getString("Perfil", ""));
									if (!link1.equals("")) {
										map.put("imagen1", link1);
									} else {
										map.put("imagen1", "none");
									}
									if (!link2.equals("")) {
										map.put("imagen2", link2);
									} else {
										map.put("imagen2", "none");
									}
									if (!link3.equals("")) {
										map.put("imagen3", link3);
									} else {
										map.put("imagen3", "none");
									}
									if (!link4.equals("")) {
										map.put("imagen4", link4);
									} else {
										map.put("imagen4", "none");
									}
									if (!link5.equals("")) {
										map.put("imagen5", link5);
									} else {
										map.put("imagen5", "none");
									}
									if (!link6.equals("")) {
										map.put("imagen6", link6);
									} else {
										map.put("imagen6", "none");
									}
									experiencia.child(key).updateChildren(map);
									map.clear();
									intet.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intet);
									finish();
								}
							} else {
								if (img == 0) {
									map = new HashMap<>();
									map.put("Titulo", edittext_titulo.getText().toString());
									map.put("Descripcion", edittext_descri.getText().toString());
									map.put("Fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
									map.put("Quienlove", vinculo.getString("vinculo", ""));
									map.put("ID", FirebaseAuth.getInstance().getCurrentUser().getUid());
									map.put("Key", key);
									map.put("Perfil", ajustes.getString("Perfil", ""));
									map.put("imagen1", "none");
									map.put("imagen2", "none");
									map.put("imagen3", "none");
									map.put("imagen4", "none");
									map.put("imagen5", "none");
									map.put("imagen6", "none");
									experiencia.child(key).updateChildren(map);
									map.clear();
									intet.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intet);
									finish();
								} else {
									map = new HashMap<>();
									map.put("Titulo", edittext_titulo.getText().toString());
									map.put("Descripcion", edittext_descri.getText().toString());
									map.put("Fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
									map.put("Quienlove", vinculo.getString("vinculo", ""));
									map.put("ID", FirebaseAuth.getInstance().getCurrentUser().getUid());
									map.put("Key", key);
									map.put("Perfil", ajustes.getString("Perfil", ""));
									if (!link1.equals("")) {
										map.put("imagen1", link1);
									} else {
										map.put("imagen1", "none");
									}
									if (!link2.equals("")) {
										map.put("imagen2", link2);
									} else {
										map.put("imagen2", "none");
									}
									if (!link3.equals("")) {
										map.put("imagen3", link3);
									} else {
										map.put("imagen3", "none");
									}
									if (!link4.equals("")) {
										map.put("imagen4", link4);
									} else {
										map.put("imagen4", "none");
									}
									if (!link5.equals("")) {
										map.put("imagen5", link5);
									} else {
										map.put("imagen5", "none");
									}
									if (!link6.equals("")) {
										map.put("imagen6", link6);
									} else {
										map.put("imagen6", "none");
									}
									experiencia.child(key).updateChildren(map);
									map.clear();
									intet.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intet);
									finish();
								}
							}
						}
					}
				}
			}
		});
		
		radiobutton1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					privado = true;
					radiobutton2.setChecked(false);
				} else {
					privado = false;
					radiobutton1.setChecked(false);
				}
			}
		});
		
		radiobutton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					privado = false;
					radiobutton1.setChecked(false);
				} else {
					privado = true;
					radiobutton2.setChecked(false);
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				img = 1;
				startActivityForResult(file, REQ_CD_FILE);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				img = 2;
				startActivityForResult(file, REQ_CD_FILE);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				img = 3;
				startActivityForResult(file, REQ_CD_FILE);
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				img = 4;
				startActivityForResult(file, REQ_CD_FILE);
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				img = 5;
				startActivityForResult(file, REQ_CD_FILE);
			}
		});
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				img = 6;
				startActivityForResult(file, REQ_CD_FILE);
			}
		});
		
		_experiencia_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		experiencia.addChildEventListener(_experiencia_child_listener);
		
		_file_experiencia_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				carga = true;
				SketchwareUtil.showMessage(getApplicationContext(), "Cagando...");
			}
		};
		
		_file_experiencia_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_file_experiencia_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				SketchwareUtil.showMessage(getApplicationContext(), "Cargado con éxito");
				carga = false;
				if (img == 1) {
					link1 = _downloadUrl;
				}
				if (img == 2) {
					link2 = _downloadUrl;
				}
				if (img == 3) {
					link3 = _downloadUrl;
				}
				if (img == 4) {
					link4 = _downloadUrl;
				}
				if (img == 5) {
					link5 = _downloadUrl;
				}
				if (img == 6) {
					link6 = _downloadUrl;
				}
			}
		};
		
		_file_experiencia_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_file_experiencia_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_file_experiencia_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		key = experiencia.push().getKey();
		radiobutton1.setChecked(true);
		privado = true;
		edittext_descri.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittext_titulo.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		if (vinculo.getString("vinculo", "").equals("")) {
			radiobutton2.setVisibility(View.GONE);
		} else {
			textview6.setVisibility(View.GONE);
		}
		linear10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF000000));
		linear9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF000000));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FILE:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				if (img == 1) {
					imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					path = _filePath.get((int)(0));
					if (path.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Error al cargar imagen, intenta con galería o otra app");
					} else {
						file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_file_experiencia_failure_listener).addOnProgressListener(_file_experiencia_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).getDownloadUrl();
							}}).addOnCompleteListener(_file_experiencia_upload_success_listener);
					}
				}
				if (img == 2) {
					imageview2.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					path = _filePath.get((int)(0));
					if (path.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Error al cargar imagen, intenta con galería o otra app");
					} else {
						file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_file_experiencia_failure_listener).addOnProgressListener(_file_experiencia_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).getDownloadUrl();
							}}).addOnCompleteListener(_file_experiencia_upload_success_listener);
					}
				}
				if (img == 3) {
					imageview3.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					path = _filePath.get((int)(0));
					if (path.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Error al cargar imagen, intenta con galería o otra app");
					} else {
						file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_file_experiencia_failure_listener).addOnProgressListener(_file_experiencia_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).getDownloadUrl();
							}}).addOnCompleteListener(_file_experiencia_upload_success_listener);
					}
				}
				if (img == 4) {
					imageview4.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					path = _filePath.get((int)(0));
					if (path.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Error al cargar imagen, intenta con galería o otra app");
					} else {
						file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_file_experiencia_failure_listener).addOnProgressListener(_file_experiencia_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).getDownloadUrl();
							}}).addOnCompleteListener(_file_experiencia_upload_success_listener);
					}
				}
				if (img == 5) {
					imageview5.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					path = _filePath.get((int)(0));
					if (path.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Error al cargar imagen, intenta con galería o otra app");
					} else {
						file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_file_experiencia_failure_listener).addOnProgressListener(_file_experiencia_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).getDownloadUrl();
							}}).addOnCompleteListener(_file_experiencia_upload_success_listener);
					}
				}
				if (img == 6) {
					imageview6.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
					path = _filePath.get((int)(0));
					if (path.equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Error al cargar imagen, intenta con galería o otra app");
					} else {
						file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_file_experiencia_failure_listener).addOnProgressListener(_file_experiencia_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return file_experiencia.child(key.concat("-img-".concat(String.valueOf((long)(img)).concat(".png")))).getDownloadUrl();
							}}).addOnCompleteListener(_file_experiencia_upload_success_listener);
					}
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (ajustes.getString("captura", "").equals("true")) {
			getWindow().setFlags(
			    WindowManager.LayoutParams.FLAG_SECURE,
			    WindowManager.LayoutParams.FLAG_SECURE
			);
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}