package com.my.misecretocontigo.alejandrostudios.mx;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import io.getstream.photoview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ReferidoActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String codigo = "";
	private double error = 0;
	private double error1 = 0;
	private double error2 = 0;
	private double error_conect = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String referidoss = "";
	private String fecha = "";
	private boolean vinculoxd = false;
	private String Nombre = "";
	private String nombre2 = "";
	
	private ArrayList<HashMap<String, Object>> map_referido = new ArrayList<>();
	private ArrayList<String> string_referido = new ArrayList<>();
	private ArrayList<String> string_promo = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map_promo = new ArrayList<>();
	private ArrayList<String> string_user = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map_user = new ArrayList<>();
	
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textviewTitle;
	private TextView textviewtext;
	private EditText edittext1;
	private MaterialButton materialbutton1;
	private TextView textview2;
	private TextView textview4;
	private LinearLayout linear8;
	private TextView textview5;
	private TextView textview6;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private DatabaseReference User = _firebase.getReference("Usuario ");
	private ChildEventListener _User_child_listener;
	private AlertDialog.Builder Dialog;
	private TimerTask timer;
	private RequestNetwork encontrar;
	private RequestNetwork.RequestListener _encontrar_request_listener;
	private SharedPreferences vinculo;
	private Calendar calendar = Calendar.getInstance();
	private Intent intent = new Intent();
	private SharedPreferences ajustes;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.referido);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textviewTitle = findViewById(R.id.textviewTitle);
		textviewtext = findViewById(R.id.textviewtext);
		edittext1 = findViewById(R.id.edittext1);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview2 = findViewById(R.id.textview2);
		textview4 = findViewById(R.id.textview4);
		linear8 = findViewById(R.id.linear8);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		auth = FirebaseAuth.getInstance();
		Dialog = new AlertDialog.Builder(this);
		encontrar = new RequestNetwork(this);
		vinculo = getSharedPreferences("vinculo", Activity.MODE_PRIVATE);
		ajustes = getSharedPreferences("ajustes", Activity.MODE_PRIVATE);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				encontrar.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _encontrar_request_listener);
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "¡Código Copiado!");
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "¡Hola! Usa este código para vincular tu cuenta conmigo en la app \"Mi secreto contigo\":\n\nCódigo de vinculación: \n".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("\nIngresa este código en tu aplicación para que podamos compartir recuerdos, secretos y experiencias de forma privada y segura."))));
			}
		});
		
		_User_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				User.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map_user = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map_user.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string_user.add(_childKey);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		User.addChildEventListener(_User_child_listener);
		
		_encontrar_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (!vinculo.getString("vinculo", "").equals("")) {
					Dialog.setTitle("Desvinculación");
					Dialog.setIcon(R.drawable.ic_info_outline_black);
					Dialog.setMessage("¿Estas seguro que te quieres desvincular de ".concat(vinculo.getString("Nombre", "").concat("?")));
					Dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							map = new HashMap<>();
							map.put("Referido", "");
							map.put("Referido-fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
							map.put("Referido-nombre", "");
							User.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
							map.clear();
							map = new HashMap<>();
							map.put("Referido", "");
							map.put("Referido-fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
							map.put("Referido-nombre", "");
							User.child(vinculo.getString("vinculo", "")).updateChildren(map);
							map.clear();
							vinculo.edit().putString("fecha", "").commit();
							vinculo.edit().putString("Nombre", "").commit();
							vinculo.edit().putString("vinculo", "").commit();
							Dialog.setTitle("!Desvinculación Exitosa¡");
							Dialog.setIcon(R.drawable.ic_notifications_on_black);
							Dialog.setMessage("Apartir de ahora, tus nuevos secretos solo lo podras ver y nadie mas");
							Dialog.setPositiveButton("Volver al inicio", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									intent.setClass(getApplicationContext(), HomeActivity.class);
									startActivity(intent);
									finish();
								}
							});
							Dialog.setCancelable(false);
							Dialog.create().show();
						}
					});
					Dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					Dialog.create().show();
				} else {
					if (!edittext1.getText().toString().equals("")) {
						if (string_user.contains(edittext1.getText().toString())) {
							if (!edittext1.getText().toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
								Nombre = map_user.get((int)string_user.indexOf(edittext1.getText().toString())).get("Nombre").toString();
								nombre2 = map_user.get((int)string_user.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Nombre").toString();
								map = new HashMap<>();
								map.put("Referido", edittext1.getText().toString());
								map.put("Referido-fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
								map.put("Referido-nombre", Nombre);
								User.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
								map.clear();
								map = new HashMap<>();
								map.put("Referido", FirebaseAuth.getInstance().getCurrentUser().getUid());
								map.put("Referido-fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime()));
								map.put("Referido-nombre", nombre2);
								User.child(edittext1.getText().toString()).updateChildren(map);
								map.clear();
								vinculo.edit().putString("vinculo", edittext1.getText().toString()).commit();
								vinculo.edit().putString("Nombre", Nombre).commit();
								vinculo.edit().putString("Fecha", new SimpleDateFormat("dd 'de' MMMM 'de' yyyy, h:mm a").format(calendar.getTime())).commit();
								Dialog.setTitle("¡Vinculación Exitosa!");
								Dialog.setIcon(R.drawable.ic_notifications_on_black);
								Dialog.setMessage("Tu cuenta ahora está conectada con ".concat(Nombre.concat(". Ya pueden compartir sus secretos y experiencias juntos.")));
								Dialog.setPositiveButton("Volver al inicio", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										intent.setClass(getApplicationContext(), HomeActivity.class);
										startActivity(intent);
										finish();
									}
								});
								Dialog.setCancelable(false);
								Dialog.create().show();
							} else {
								Dialog.setTitle("Usuario No Encontrado");
								Dialog.setIcon(R.drawable.ic_error_black);
								Dialog.setMessage("No pudimos encontrar una cuenta con ese código. Verifica que te haya compartido el código correcto.");
								Dialog.setPositiveButton("Volver a intentar", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										encontrar.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _encontrar_request_listener);
									}
								});
								Dialog.setNegativeButton("Cerrar", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										
									}
								});
								Dialog.create().show();
							}
						} else {
							Dialog.setTitle("Usuario No Encontrado");
							Dialog.setIcon(R.drawable.ic_error_black);
							Dialog.setMessage("No pudimos encontrar una cuenta con ese código. Verifica que te haya compartido el código correcto.");
							Dialog.setPositiveButton("Volver a intentar", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									encontrar.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _encontrar_request_listener);
								}
							});
							Dialog.setNegativeButton("Cerrar", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									
								}
							});
							Dialog.create().show();
						}
					} else {
						((EditText)edittext1).setError("Ingresa el código de vinculación");
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Error de conexión, por favor verifica tu conexión a internet o datos móviles e intenta mas tarde");
				materialbutton1.setEnabled(false);
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		linear6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
		textview5.setText(FirebaseAuth.getInstance().getCurrentUser().getUid());
		setTitle("Tu rincón privado con quien más quieres");
		if (vinculo.getString("vinculo", "").equals("")) {
			vinculoxd = false;
		} else {
			textviewTitle.setText("Estado de vinculación");
			textviewtext.setText("Actualmente estás vinculado con: ".concat(vinculo.getString("Nombre", "").concat(", Fecha de vinculación: ".concat(vinculo.getString("Fecha", "").concat(". Puedes desvincularte en cualquier momento.")))));
			materialbutton1.setText("Desvincular");
			edittext1.setVisibility(View.GONE);
			vinculoxd = true;
		}
		if (ajustes.getString("captura", "").equals("true")) {
			getWindow().setFlags(
			    WindowManager.LayoutParams.FLAG_SECURE,
			    WindowManager.LayoutParams.FLAG_SECURE
			);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}