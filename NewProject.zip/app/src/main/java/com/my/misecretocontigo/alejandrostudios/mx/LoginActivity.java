package com.my.misecretocontigo.alejandrostudios.mx;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import io.getstream.photoview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class LoginActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double sesion = 0;
	private HashMap<String, Object> mapp = new HashMap<>();
	private boolean contrasena = false;
	private boolean contrasena1 = false;
	private boolean contrasena2 = false;
	
	private ArrayList<String> string = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview13;
	private LinearLayout linear_login;
	private LinearLayout linear_crea;
	private TextView textview1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear9;
	private MaterialButton materialbutton1;
	private TextView textview2;
	private EditText edittext_c_l;
	private TextView textview3;
	private LinearLayout linearp_l;
	private EditText edittext_p_l;
	private ImageView imageview1;
	private TextView textview8;
	private TextView textview9;
	private TextView textview4;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear10;
	private MaterialButton materialbutton2;
	private TextView textview6;
	private EditText edittext_c_c;
	private TextView textview5;
	private LinearLayout linearp_c;
	private EditText edittextp_c;
	private ImageView imageview2;
	private TextView textview7;
	private LinearLayout linearp_cc;
	private EditText edittextp_cc;
	private ImageView imageview3;
	private TextView textview10;
	private TextView textview11;
	
	private Intent intent = new Intent();
	private AlertDialog.Builder Dialog;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private DatabaseReference Usuario = _firebase.getReference("Usuario");
	private ChildEventListener _Usuario_child_listener;
	private SharedPreferences Usuario1;
	private SharedPreferences data;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		textview13 = findViewById(R.id.textview13);
		linear_login = findViewById(R.id.linear_login);
		linear_crea = findViewById(R.id.linear_crea);
		textview1 = findViewById(R.id.textview1);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear9 = findViewById(R.id.linear9);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview2 = findViewById(R.id.textview2);
		edittext_c_l = findViewById(R.id.edittext_c_l);
		textview3 = findViewById(R.id.textview3);
		linearp_l = findViewById(R.id.linearp_l);
		edittext_p_l = findViewById(R.id.edittext_p_l);
		imageview1 = findViewById(R.id.imageview1);
		textview8 = findViewById(R.id.textview8);
		textview9 = findViewById(R.id.textview9);
		textview4 = findViewById(R.id.textview4);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear10 = findViewById(R.id.linear10);
		materialbutton2 = findViewById(R.id.materialbutton2);
		textview6 = findViewById(R.id.textview6);
		edittext_c_c = findViewById(R.id.edittext_c_c);
		textview5 = findViewById(R.id.textview5);
		linearp_c = findViewById(R.id.linearp_c);
		edittextp_c = findViewById(R.id.edittextp_c);
		imageview2 = findViewById(R.id.imageview2);
		textview7 = findViewById(R.id.textview7);
		linearp_cc = findViewById(R.id.linearp_cc);
		edittextp_cc = findViewById(R.id.edittextp_cc);
		imageview3 = findViewById(R.id.imageview3);
		textview10 = findViewById(R.id.textview10);
		textview11 = findViewById(R.id.textview11);
		Dialog = new AlertDialog.Builder(this);
		auth = FirebaseAuth.getInstance();
		Usuario1 = getSharedPreferences("Usuario", Activity.MODE_PRIVATE);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		textview13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SoporteActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_c_l.getText().toString().equals("")) {
					((EditText)edittext_c_l).setError("Por favor ingresa tu correo");
				} else {
					if (edittext_p_l.getText().toString().equals("")) {
						((EditText)edittext_p_l).setError("Por favor ingresa tu contraseña ");
					} else {
						auth.signInWithEmailAndPassword(edittext_c_l.getText().toString(), edittext_p_l.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
					}
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (contrasena) {
					edittext_p_l.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
					imageview1.setImageResource(R.drawable.ic_visibility_off_black);
					contrasena = false;
				} else {
					edittext_p_l.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
					imageview1.setImageResource(R.drawable.ic_visibility_black);
					contrasena = true;
				}
			}
		});
		
		textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sesion = 1;
				linear_login.setVisibility(View.GONE);
				linear_crea.setVisibility(View.VISIBLE);
			}
		});
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_c_c.getText().toString().equals("")) {
					((EditText)edittext_c_c).setError("Ingresa tu correo ");
				} else {
					if (edittextp_c.getText().toString().equals("")) {
						((EditText)edittextp_c).setError("Crea una contraseña");
					} else {
						if (edittextp_cc.getText().toString().equals("")) {
							((EditText)edittextp_cc).setError("Confirma tu contraseña ");
						} else {
							if (edittextp_c.getText().toString().equals(edittextp_cc.getText().toString())) {
								auth.createUserWithEmailAndPassword(edittext_c_c.getText().toString(), edittextp_c.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
							} else {
								((EditText)edittextp_cc).setError("Tus contraseñas no coinciden");
							}
						}
					}
				}
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (contrasena1) {
					edittextp_c.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
					imageview2.setImageResource(R.drawable.ic_visibility_off_black);
					contrasena1 = false;
				} else {
					edittextp_c.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
					imageview2.setImageResource(R.drawable.ic_visibility_black);
					contrasena1 = true;
				}
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (contrasena2) {
					edittextp_cc.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
					imageview3.setImageResource(R.drawable.ic_visibility_off_black);
					contrasena2 = false;
				} else {
					edittextp_cc.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
					imageview3.setImageResource(R.drawable.ic_visibility_black);
					contrasena2 = true;
				}
			}
		});
		
		textview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sesion = 0;
				linear_crea.setVisibility(View.GONE);
				linear_login.setVisibility(View.VISIBLE);
			}
		});
		
		_Usuario_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Usuario.addChildEventListener(_Usuario_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					FirebaseAuth.getInstance().signOut();
					SketchwareUtil.showMessage(getApplicationContext(), "Correo de verificación enviado ");
					intent.setClass(getApplicationContext(), MainActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(intent);
					finish();
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					Dialog.setTitle("Felicidades");
					Dialog.setIcon(R.drawable.ic_email_black);
					Dialog.setMessage("Tu cuenta se creo con éxito, ahora vamos a verificar tu correo ");
					Dialog.setPositiveButton("Verificar correo", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							FirebaseAuth.getInstance().signOut();
							data.edit().putString("contraseña", edittextp_cc.getText().toString()).commit();
							Usuario1.edit().putString("correo", edittext_c_c.getText().toString()).commit();
							Usuario1.edit().putString("contraseña", edittextp_cc.getText().toString()).commit();
							auth.signInWithEmailAndPassword(edittext_c_c.getText().toString(), edittextp_cc.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
							intent.setClass(getApplicationContext(), MainActivity.class);
							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(intent);
							finish();
						}
					});
					Dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					Dialog.setCancelable(true);
					Dialog.create().show();
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()) {
						Usuario1.edit().putString("ID", FirebaseAuth.getInstance().getCurrentUser().getUid()).commit();
						if (string.contains(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (map.get((int)string.indexOf(FirebaseAuth.getInstance().getCurrentUser().getUid())).get("Contraseña").toString().equals("")) {
								mapp = new HashMap<>();
								mapp.put("Contraseña", edittext_p_l.getText().toString());
								Usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(mapp);
								mapp.clear();
								data.edit().putString("contraseña", edittext_p_l.getText().toString()).commit();
								Usuario1.edit().putString("contraseña", edittext_p_l.getText().toString()).commit();
								intent.setClass(getApplicationContext(), MainActivity.class);
								intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(intent);
								finish();
							} else {
								data.edit().putString("contraseña", edittext_p_l.getText().toString()).commit();
								intent.putExtra("contraseña", edittext_p_l.getText().toString());
								intent.setClass(getApplicationContext(), MainActivity.class);
								intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(intent);
								finish();
							}
						} else {
							intent.setClass(getApplicationContext(), MainActivity.class);
							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(intent);
							finish();
						}
					} else {
						FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(auth_emailVerificationSentListener);
					}
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		sesion = 0;
		setTitle("¡BIENVENID@!");
		edittext_c_l.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittext_p_l.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittext_c_c.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittextp_c.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittextp_cc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		if (sesion == 1) {
			linear_login.setVisibility(View.GONE);
			linear_crea.setVisibility(View.VISIBLE);
		}
		if (sesion == 0) {
			linear_login.setVisibility(View.VISIBLE);
			linear_crea.setVisibility(View.GONE);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}