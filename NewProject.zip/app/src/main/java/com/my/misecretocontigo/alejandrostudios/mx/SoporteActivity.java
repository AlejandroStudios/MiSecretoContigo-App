package com.my.misecretocontigo.alejandrostudios.mx;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import io.getstream.photoview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SoporteActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linearcentral;
	private TextView textview1;
	private TextView textview2;
	private MaterialButton materialbutton2;
	private TextView textview3;
	private TextView textview4;
	private MaterialButton materialbutton4;
	private MaterialButton materialbutton5;
	private MaterialButton materialbutton6;
	private MaterialButton materialbutton7;
	
	private AlertDialog.Builder dialog;
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.soporte);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		vscroll1 = findViewById(R.id.vscroll1);
		linearcentral = findViewById(R.id.linearcentral);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		materialbutton2 = findViewById(R.id.materialbutton2);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		materialbutton4 = findViewById(R.id.materialbutton4);
		materialbutton5 = findViewById(R.id.materialbutton5);
		materialbutton6 = findViewById(R.id.materialbutton6);
		materialbutton7 = findViewById(R.id.materialbutton7);
		dialog = new AlertDialog.Builder(this);
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Aviso Importante");
				dialog.setIcon(R.drawable.ic_notifications_on_black);
				dialog.setMessage("Con mucho gusto te ayudaremos a resolver tus preguntas, el tiempo de respuesta no es fijo, lo sentimos por el momento no contamos con mucho personal, te agradecería de todo corazón tu comprensión y paciencia");
				dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						Intent emailIntent = new Intent(intent.ACTION_SEND);
						emailIntent.setType("message/rfc822"); // Indica que es un correo electrónico
						
						// Destinatarios
						emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[] {"studioswolffid@gmail.com"}); 
						
						// Asunto
						emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Escribe aquí tu pregunta o duda");
						
						// Cuerpo del mensaje
						emailIntent.putExtra(Intent.EXTRA_TEXT, "Si deseas puedes explicar un poco mas");
						
						// Iniciar la actividad para que el usuario elija el cliente de correo
						startActivity(Intent.createChooser(emailIntent, "Enviar correo..."));
						
					}
				});
				dialog.setNegativeButton("cerrar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		});
		
		materialbutton4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Aviso Importante");
				dialog.setIcon(R.drawable.ic_notifications_on_black);
				dialog.setMessage("Con mucho gusto te ayudaremos a resolver tus preguntas, el tiempo de respuesta no es fijo, lo sentimos por el momento no contamos con mucho personal, te agradecería de todo corazón tu comprensión y paciencia");
				dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setData(Uri.parse("https://wa.me/qr/2PBV42BSCQTKH1"));
						intent.setAction(Intent.ACTION_VIEW);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("cerrar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		});
		
		materialbutton5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Aviso Importante");
				dialog.setIcon(R.drawable.ic_notifications_on_black);
				dialog.setMessage("Con mucho gusto te ayudaremos a resolver tus preguntas, el tiempo de respuesta no es fijo, lo sentimos por el momento no contamos con mucho personal, te agradecería de todo corazón tu comprensión y paciencia");
				dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setData(Uri.parse("https://t.me/m/hn2gQF-5MmJh"));
						intent.setAction(Intent.ACTION_VIEW);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("cerrar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		});
		
		materialbutton6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Aviso Importante");
				dialog.setIcon(R.drawable.ic_notifications_on_black);
				dialog.setMessage("Con mucho gusto te ayudaremos a resolver tus preguntas, el tiempo de respuesta no es fijo, lo sentimos por el momento no contamos con mucho personal, te agradecería de todo corazón tu comprensión y paciencia");
				dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						Intent emailIntent = new Intent(Intent.ACTION_SEND);
						emailIntent.setType("message/rfc822"); // Indica que es un correo electrónico
						
						// Destinatarios
						emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[] {"studioswolffid@gmail.com"}); 
						
						// Asunto
						emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Tengo un problema");
						
						// Cuerpo del mensaje
						emailIntent.putExtra(Intent.EXTRA_TEXT, "Por favor explicamos más sobre el problema que presentas y si es posible adjunta algunas evidencias");
						
						// Iniciar la actividad para que el usuario elija el cliente de correo
						startActivity(Intent.createChooser(emailIntent, "Enviar correo..."));
						
					}
				});
				dialog.setNegativeButton("cerrar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		});
		
		materialbutton7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Aviso Importante");
				dialog.setIcon(R.drawable.ic_notifications_on_black);
				dialog.setMessage("Con mucho gusto te ayudaremos a resolver tus preguntas, el tiempo de respuesta no es fijo, lo sentimos por el momento no contamos con mucho personal, te agradecería de todo corazón tu comprensión y paciencia");
				dialog.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setData(Uri.parse("https://www.socialcreator.com/studioswolffidoficial/?s=281228"));
						intent.setAction(Intent.ACTION_VIEW);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("cerrar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		});
	}
	
	private void initializeLogic() {
		setTitle("Soporte");
		linearcentral.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFAF4));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}