package com.my.misecretocontigo.alejandrostudios.mx;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.resources.*;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.*;
import androidx.biometric.*;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.ktx.*;
import androidx.cursoradapter.*;
import androidx.customview.*;
import androidx.drawerlayout.*;
import androidx.emoji2.*;
import androidx.emoji2.viewsintegration.*;
import androidx.exifinterface.*;
import androidx.fragment.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.*;
import androidx.lifecycle.livedata.*;
import androidx.lifecycle.livedata.core.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.runtime.*;
import androidx.lifecycle.viewmodel.*;
import androidx.lifecycle.viewmodel.savedstate.*;
import androidx.loader.*;
import androidx.profileinstaller.*;
import androidx.savedstate.*;
import androidx.startup.*;
import androidx.tracing.*;
import androidx.vectordrawable.*;
import androidx.vectordrawable.animated.*;
import androidx.versionedparcelable.*;
import androidx.viewpager.*;
import com.bumptech.glide.*;
import com.bumptech.glide.gifdecoder.*;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import io.getstream.photoview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PerfilActivity extends AppCompatActivity {
	
	public final int REQ_CD_PICK = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String img = "";
	private String name = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String genero = "";
	private double codigo_ref = 0;
	private boolean listo = false;
	private HashMap<String, Object> map_reff = new HashMap<>();
	private double act = 0;
	
	private ArrayList<HashMap<String, Object>> mapp = new ArrayList<>();
	private ArrayList<String> string = new ArrayList<>();
	private ArrayList<String> string_referido = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map_ref = new ArrayList<>();
	
	private ScrollView vscroll1;
	private TextView textview9;
	private LinearLayout linear9;
	private LinearLayout linear1;
	private ProgressBar progressbar1;
	private CircleImageView circleimageview1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear10;
	private MaterialButton materialbutton1;
	private TextView textview2;
	private EditText edittext_name;
	private TextView textview1;
	private EditText edittext_apellido;
	private TextView textview3;
	private EditText edittext_naci;
	private TextView textview4;
	private RadioButton radiobutton_m;
	private RadioButton radiobutton_f;
	private TextView textview5;
	private TextView textview_correo;
	private TextView textview7;
	private TextView textview_id;
	private TextView textview10;
	private EditText edittext_referido;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference perfil = _firebase_storage.getReference("perfil");
	private OnCompleteListener<Uri> _perfil_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _perfil_download_success_listener;
	private OnSuccessListener _perfil_delete_success_listener;
	private OnProgressListener _perfil_upload_progress_listener;
	private OnProgressListener _perfil_download_progress_listener;
	private OnFailureListener _perfil_failure_listener;
	private DatabaseReference Usuario = _firebase.getReference("Usuario ");
	private ChildEventListener _Usuario_child_listener;
	private Intent intent = new Intent();
	private AlertDialog.Builder dialog;
	private SharedPreferences Usuario1;
	private Calendar calendar = Calendar.getInstance();
	private RequestNetwork very;
	private RequestNetwork.RequestListener _very_request_listener;
	private SharedPreferences data;
	private DatabaseReference referido = _firebase.getReference("Referido");
	private ChildEventListener _referido_child_listener;
	private RequestNetwork verificador_2;
	private RequestNetwork.RequestListener _verificador_2_request_listener;
	private RequestNetwork Comprobar;
	private RequestNetwork.RequestListener _Comprobar_request_listener;
	private SharedPreferences vinculo;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.perfil);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		textview9 = findViewById(R.id.textview9);
		linear9 = findViewById(R.id.linear9);
		linear1 = findViewById(R.id.linear1);
		progressbar1 = findViewById(R.id.progressbar1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear10 = findViewById(R.id.linear10);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview2 = findViewById(R.id.textview2);
		edittext_name = findViewById(R.id.edittext_name);
		textview1 = findViewById(R.id.textview1);
		edittext_apellido = findViewById(R.id.edittext_apellido);
		textview3 = findViewById(R.id.textview3);
		edittext_naci = findViewById(R.id.edittext_naci);
		textview4 = findViewById(R.id.textview4);
		radiobutton_m = findViewById(R.id.radiobutton_m);
		radiobutton_f = findViewById(R.id.radiobutton_f);
		textview5 = findViewById(R.id.textview5);
		textview_correo = findViewById(R.id.textview_correo);
		textview7 = findViewById(R.id.textview7);
		textview_id = findViewById(R.id.textview_id);
		textview10 = findViewById(R.id.textview10);
		edittext_referido = findViewById(R.id.edittext_referido);
		auth = FirebaseAuth.getInstance();
		pick.setType("image/*");
		pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		dialog = new AlertDialog.Builder(this);
		Usuario1 = getSharedPreferences("Usuario", Activity.MODE_PRIVATE);
		very = new RequestNetwork(this);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		verificador_2 = new RequestNetwork(this);
		Comprobar = new RequestNetwork(this);
		vinculo = getSharedPreferences("vinculo", Activity.MODE_PRIVATE);
		
		textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SoporteActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(pick, REQ_CD_PICK);
			}
		});
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (img.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Por favor coloca una foto de perfil ");
				} else {
					if (edittext_name.getText().toString().equals("")) {
						((EditText)edittext_name).setError("Ingresa tu nombre");
					} else {
						if (edittext_apellido.getText().toString().equals("")) {
							((EditText)edittext_apellido).setError("Ingresa tu apellido");
						} else {
							if (edittext_naci.getText().toString().equals("")) {
								((EditText)edittext_naci).setError("Ingresa tu fecha de nacimiento ");
							} else {
								if (!edittext_referido.getText().toString().equals("")) {
									Comprobar.startRequestNetwork(RequestNetworkController.GET, "https://www.studioswolffid.shop/", "A", _Comprobar_request_listener);
								} else {
									if (radiobutton_m.isChecked()) {
										if (listo) {
											perfil.child(name).putFile(Uri.fromFile(new File(img))).addOnFailureListener(_perfil_failure_listener).addOnProgressListener(_perfil_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
												@Override
												public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
													return perfil.child(name).getDownloadUrl();
												}}).addOnCompleteListener(_perfil_upload_success_listener);
										} else {
											SketchwareUtil.showMessage(getApplicationContext(), "Estamos haciendo unos ajustes... Inténtalo nuevamente en unos segundos...");
										}
									} else {
										if (radiobutton_f.isChecked()) {
											if (listo) {
												perfil.child(name).putFile(Uri.fromFile(new File(img))).addOnFailureListener(_perfil_failure_listener).addOnProgressListener(_perfil_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
													@Override
													public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
														return perfil.child(name).getDownloadUrl();
													}}).addOnCompleteListener(_perfil_upload_success_listener);
											} else {
												SketchwareUtil.showMessage(getApplicationContext(), "Estamos haciendo unos ajustes... Inténtalo nuevamente en unos segundos...");
											}
										} else {
											SketchwareUtil.showMessage(getApplicationContext(), "Por favor seleccióna tu género");
										}
									}
								}
							}
						}
					}
				}
			}
		});
		
		radiobutton_m.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				radiobutton_m.setChecked(true);
				genero = "Masculino";
				radiobutton_f.setChecked(false);
			}
		});
		
		radiobutton_f.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				radiobutton_f.setChecked(true);
				genero = "Femenino";
				radiobutton_m.setChecked(false);
			}
		});
		
		_perfil_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				progressbar1.setVisibility(View.VISIBLE);
				progressbar1.setProgress((int)_progressValue);
			}
		};
		
		_perfil_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_perfil_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				act++;
				map = new HashMap<>();
				map.put("Perfil", _downloadUrl);
				map.put("Nombre", edittext_name.getText().toString());
				map.put("Apellidos", edittext_apellido.getText().toString());
				map.put("Fecha de nacimiento", edittext_naci.getText().toString());
				map.put("Genero", genero);
				map.put("Correo", FirebaseAuth.getInstance().getCurrentUser().getEmail());
				map.put("ID", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("Contraseña", data.getString("contraseña", ""));
				map.put("Creado", new SimpleDateFormat("dd/MM/yyyy").format(calendar.getTime()));
				map.put("Puntos", "0");
				map.put("Recompensa", "No");
				map.put("Dia", new SimpleDateFormat("dd").format(calendar.getTime()));
				calendar.add(Calendar.MONTH, (int)(4));
				map.put("Mes", new SimpleDateFormat("MM").format(calendar.getTime()));
				map.put("Año", new SimpleDateFormat("yyyy").format(calendar.getTime()));
				map.put("Codigo", String.valueOf((long)(codigo_ref)));
				map.put("Referido-fecha", "");
				map.put("Referido-nombre", "");
				if (edittext_referido.getText().toString().equals("")) {
					map.put("Referido", "");
				} else {
					map.put("Referido", edittext_referido.getText().toString());
					vinculo.edit().putString("vinculo", edittext_referido.getText().toString()).commit();
				}
				Usuario.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
				map_reff = new HashMap<>();
				map_reff.put("Nombre", edittext_name.getText().toString());
				map_reff.put("ID", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map_reff.put("Codigo", String.valueOf((long)(codigo_ref)));
				map_reff.put("Codigo Referido", edittext_referido.getText().toString());
				map_reff.put("Fecha", new SimpleDateFormat("dd/MM/yyyy").format(calendar.getTime()));
				referido.child(String.valueOf((long)(codigo_ref))).updateChildren(map_reff);
				map_reff.clear();
				dialog.setTitle("Ya terminamos!");
				dialog.setIcon(R.drawable.ic_security_black);
				dialog.setMessage("Tu perfil fue creado con exito, ya puedes escribir y compartir tus secretos!");
				dialog.setPositiveButton("Finalizar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setClass(getApplicationContext(), MainActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
						finish();
					}
				});
				dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dialog.setCancelable(false);
				dialog.create().show();
			}
		};
		
		_perfil_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_perfil_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_perfil_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_Usuario_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Usuario.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						mapp = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								mapp.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string.add(_childKey);
						if (act == 0) {
							very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Usuario.addChildEventListener(_Usuario_child_listener);
		
		_very_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (string.contains(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					dialog.setTitle("Seguridad");
					dialog.setIcon(R.drawable.ic_security_black);
					dialog.setMessage("Hemos detectado que ya tienes una cuenta, por favor verifica tu conexión a internet o datos móviles");
					dialog.setPositiveButton("Reiniciar", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							intent.setClass(getApplicationContext(), MainActivity.class);
							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(intent);
							finish();
						}
					});
					dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finish();
						}
					});
					dialog.setCancelable(false);
					dialog.create().show();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				dialog.setTitle("Ups!");
				dialog.setIcon(R.drawable.ic_signal_wifi_statusbar_not_connected_black);
				dialog.setMessage("Por favor verifica tu conexión a internet o datos y intenta mas tarde ");
				dialog.setPositiveButton("Volver a intentar ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						very.startRequestNetwork(RequestNetworkController.GET, "https://google com", "A", _very_request_listener);
					}
				});
				dialog.setNeutralButton("Soporte", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setClass(getApplicationContext(), SoporteActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dialog.setCancelable(true);
				dialog.create().show();
			}
		};
		
		_referido_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				referido.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map_ref = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map_ref.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string_referido.add(_childKey);
						if (act == 0) {
							verificador_2.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _verificador_2_request_listener);
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				referido.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map_ref = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map_ref.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						string_referido.add(_childKey);
						if (act == 0) {
							verificador_2.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _verificador_2_request_listener);
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		referido.addChildEventListener(_referido_child_listener);
		
		_verificador_2_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				codigo_ref = SketchwareUtil.getRandom((int)(10000), (int)(99999));
				if (string_referido.contains(String.valueOf((long)(codigo_ref)))) {
					verificador_2.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "A", _verificador_2_request_listener);
					listo = false;
				} else {
					listo = true;
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				dialog.setTitle("Ups!");
				dialog.setIcon(R.drawable.ic_signal_wifi_statusbar_not_connected_black);
				dialog.setMessage("Por favor verifica tu conexión a internet o datos y intenta mas tarde ");
				dialog.setPositiveButton("Volver a intentar ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
					}
				});
				dialog.setNeutralButton("Soporte", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setClass(getApplicationContext(), SoporteActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dialog.setCancelable(true);
				dialog.create().show();
			}
		};
		
		_Comprobar_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (string_referido.contains(edittext_referido.getText().toString())) {
					if (radiobutton_m.isChecked()) {
						if (listo) {
							perfil.child(name).putFile(Uri.fromFile(new File(img))).addOnFailureListener(_perfil_failure_listener).addOnProgressListener(_perfil_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
								@Override
								public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
									return perfil.child(name).getDownloadUrl();
								}}).addOnCompleteListener(_perfil_upload_success_listener);
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "Estamos haciendo unos ajustes... Inténtalo nuevamente en unos segundos...");
						}
					} else {
						if (radiobutton_f.isChecked()) {
							if (listo) {
								perfil.child(name).putFile(Uri.fromFile(new File(img))).addOnFailureListener(_perfil_failure_listener).addOnProgressListener(_perfil_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
									@Override
									public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
										return perfil.child(name).getDownloadUrl();
									}}).addOnCompleteListener(_perfil_upload_success_listener);
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "Estamos haciendo unos ajustes... Inténtalo nuevamente en unos segundos...");
							}
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "Por favor seleccióna tu género");
						}
					}
				} else {
					((EditText)edittext_referido).setError("No existe, por favor verifica si esta correcto");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				dialog.setTitle("Ups!");
				dialog.setIcon(R.drawable.ic_signal_wifi_statusbar_not_connected_black);
				dialog.setMessage("Por favor verifica tu conexión a internet o datos y intenta mas tarde ");
				dialog.setPositiveButton("Volver a intentar ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						very.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "A", _very_request_listener);
					}
				});
				dialog.setNeutralButton("Soporte", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						intent.setClass(getApplicationContext(), SoporteActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(intent);
					}
				});
				dialog.setNegativeButton("Salir", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dialog.setCancelable(true);
				dialog.create().show();
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Perfil");
		very.startRequestNetwork(RequestNetworkController.GET, "https://www.studioswolffid.shop/", "A", _very_request_listener);
		textview_id.setText(FirebaseAuth.getInstance().getCurrentUser().getUid());
		textview_correo.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
		edittext_name.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittext_apellido.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittext_naci.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_correo.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		textview_id.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		edittext_referido.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFE0E0E0));
		linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		name = FirebaseAuth.getInstance().getCurrentUser().getUid().concat("+".concat(Usuario.push().getKey()));
		progressbar1.setVisibility(View.GONE);
		linear10.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PICK:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				circleimageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
				img = _filePath.get((int)(0));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}